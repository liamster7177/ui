# DROIDWARE UI

Fork of `skyfallHosting/skyfallUserInterface`, debranded and extended for the
DROIDWARE hub. Everything the hub used to patch into the library at runtime
with string replacement is now baked into the source.

## Loading

```lua
local library = loadstring(game:HttpGet(
  "https://raw.githubusercontent.com/<YOUR_USER>/droidware-ui/main/main"))()
```

Put this file in the repo root, named `main`, with no extension — that keeps
the raw URL above working.

## What changed from upstream

| Change | Why |
|---|---|
| Window size is data-driven | `library.windowWidth` / `.windowHeight` drive **every** panel; the groupbox columns reflow instead of zooming |
| Three groupbox columns | `AddMidGroupbox` added; column width is `(baseW - 24) / 3` |
| Circle nav icons | `LucideForTab` always returns `circle` |
| Labels clip | toggle and dropdown labels truncate instead of running under their control |
| Nav fits | tab buttons 28px with 4px padding, so 9+ tabs render |
| `library.ToggleMenu` | lets the hub's own bar open/close the window |
| No built-in watermark | the hub draws its own |
| No built-in Settings tab | the hub owns Settings |
| Debranded | all SKYFALL strings → DROIDWARE |

## Window sizing

```lua
library.windowWidth  = 1060   -- default, clamped 720..1920
library.windowHeight = 620    -- default, clamped 460..1080
library:SetWindowSize(1200, 700)
```

Both are re-read on every `Init()`, so resizing means setting them and
rebuilding. Everything derives from them:

```
edge            W          x H
background      W - 2      x H - 2
sidebar         190        x H - 86
nav list        188        x H - 200
container       W - 224    x H - 88
page            W - 224    x H - 150
groupbox width  W - 256          -> each column (that - 24) / 3
```

## Added API

### Panels

```lua
local sg, content, skin, titleLabel =
    library:MakePanel("myPanel", "CHARACTER", 310, 440, 80, 110)
```

Clones the live window frame, strips the sidebar and content, and reflows the
header for panel width — so the gradient, stroke, corner radius and fonts are
the *same instances* as the main window, not an imitation. Draggable by its
header, resizable from all four corners, closes itself. Falls back to a plain
shell in the same palette if the window is not up yet.

Content positions against `content`, whose header occupies the top 34px.

### Window resize grip

```lua
library:AddWindowResizeGrip(function(w, h)
    -- windowWidth/Height are already set; rebuild to apply
    rebuildMyUI()
end)
```

Drag shows an outline; releasing commits the size and fires the callback.

### Helpers

```lua
library:LiveWindow()                      -- edge, background (searches every GUI host)
library:Skin()                            -- {accent,bg,panel,text,muted,radius,trans}
library:DressLikeWindow(frame, skin)      -- clone the window's gradient/ambience/stroke
library:MakeDraggable(root, handle)
library:AddCornerGrips(root, target, skin, minW, minH, onDone)
library:HoldConn(gui, conn)               -- connection dies with the GUI
library:CleanCharacterClone(model)        -- strip drawables before a ViewportFrame
library:Sweep("skyfall", "DROIDWARE")     -- kill leftovers from an older run
library:Host()
```

`HoldConn` matters: a panel that connects to `UserInputService` and never
disconnects leaks a handler per open, and the GUI it captures is never
collected. Every connection the functions above make is already held.

## Upstream

Original: https://github.com/skyfallHosting/skyfallUserInterface
